<?php
/* Include all individual CPT. */
$prefix_cpt = "cpt_";

/* Gallery */
require_once( $prefix_cpt . "gallery.php" );
?>